# read_config
Read redis config DB for other modules
